import axios from "axios";

const api = axios.create({
  baseURL: "http://127.0.0.1:8000",
});

api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("token");

    console.log("JWT Token:", token);

    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }

    console.log("Request Headers:", config.headers);

    return config;
  },
  (error) => Promise.reject(error)
);

export default api;